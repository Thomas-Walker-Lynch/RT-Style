// developer/authored/RT/element/citation.js
window.StyleRT = window.StyleRT || {};

window.StyleRT.citation = function(){
  const citations = document.querySelectorAll('rt-cite');
  if(citations.length === 0) return;

  // Locate or generate the endnotes container
  let endnoteContainer = document.querySelector('rt-endnotes');
  if(!endnoteContainer) {
    endnoteContainer = document.createElement('rt-endnotes');
    endnoteContainer.innerHTML = '<h2>Endnotes</h2><ol></ol>';
    
    // Append it to the end of the article, before pagination evaluates the DOM
    const article = document.querySelector('rt-article');
    if(article) {
      article.appendChild(endnoteContainer);
    }
  }
  
  const list = endnoteContainer.querySelector('ol');
  if(!list) return;

  // Process each inline citation
  citations.forEach((cite, index) => {
    const refNum = index + 1;
    const refText = cite.getAttribute('ref') || cite.innerHTML;
    
    // 1. Transform the inline tag into a superscript link
    cite.innerHTML = `<sup><a href="#note-${refNum}" id="cite-${refNum}">[${refNum}]</a></sup>`;
    cite.style.cursor = 'pointer';
    cite.style.color = 'var(--rt-brand-link)';
    cite.style.textDecoration = 'none';

    // 2. Append the corresponding entry into the endnotes list
    const li = document.createElement('li');
    li.id = `note-${refNum}`;
    
    // Add a return link arrow to jump back to the text
    li.innerHTML = `${refText} <a href="#cite-${refNum}" style="text-decoration:none;">&#8617;</a>`;
    list.appendChild(li);
  });
  
  // Style the container
  endnoteContainer.style.display = 'block';
  endnoteContainer.style.marginTop = '3rem';
  endnoteContainer.style.borderTop = '1px solid var(--rt-surface-3)';
  endnoteContainer.style.paddingTop = '1rem';
};
